Here is how to run:
java -jar "F:\binarySearchTree\dist\binarySearchTree.jar"

******************************************************************************
Note: Please replace F with your directory to where this jar file is copied.
******************************************************************************